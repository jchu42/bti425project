// pages/register.js

import Register from './components/Register';

const RegisterPage = () => {
    return (
        <div>
            {/* <h1>User Registration</h1> */}
            <Register />
        </div>
    );
};

export default RegisterPage;
