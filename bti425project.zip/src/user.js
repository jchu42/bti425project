import {atom, useAtom} from 'jotai';

export const loggedInAtom = atom(false)
export const favoritesAtom = atom([])
export const historyAtom = atom([])