import {atom, useAtom} from 'jotai';

export const searchAtom = atom("");
export const dataAtom = atom([]);
export const errorAtom = atom(true);