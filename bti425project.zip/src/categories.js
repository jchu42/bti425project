export default[
    {
        "ID": "cat-00",
        "Description": "all places"
    },
    {
        "ID": "cat-01",
        "Description": "park"
    },
    {
        "ID": "cat-02",
        "Description": "free"
    },
    {
        "ID": "cat-03",
        "Description": "paid"
    },
    {
        "ID": "cat-04",
        "Description": "fishing"
    },
    {
        "ID": "cat-05",
        "Description": "hiking"
    },
    {
        "ID": "cat-06",
        "Description": "exercise"
    },
    {
        "ID": "cat-07",
        "Description": "animals"
    },
    {
        "ID": "cat-08",
        "Description": "outdoors"
    },
    {
        "ID": "cat-09",
        "Description": "indoors"
    },
    {
        "ID": "cat-10",
        "Description": "downtown"
    },
    {
        "ID": "cat-11",
        "Description": "shopping"
    }
]
