export default[
    {
        "ID": "cat-00",
        "Description": "all places",
        "Image": "categories_images\\allplaces.jpg"
    },
    {
        "ID": "cat-01",
        "Description": "parks",
        "Image": "categories_images\\park.jpg"
    },
    {
        "ID": "cat-02",
        "Description": "free",
        "Image": "categories_images\\free.jpg"
    },
    {
        "ID": "cat-03",
        "Description": "paid",
        "Image": "categories_images\\paid.jpg"
    },
    {
        "ID": "cat-04",
        "Description": "fishing",
        "Image": "categories_images\\fishing.jpg"
    },
    {
        "ID": "cat-05",
        "Description": "hiking",
        "Image": "categories_images\\hiking.jpg"
    },
    {
        "ID": "cat-06",
        "Description": "exercise",
        "Image": "categories_images\\exercise.jpg"
    },
    {
        "ID": "cat-07",
        "Description": "animals",
        "Image": "categories_images\\animal.jpg"
    },
    {
        "ID": "cat-08",
        "Description": "outdoors",
        "Image": "categories_images\\outdoor.jpg"
    },
    {
        "ID": "cat-09",
        "Description": "indoors",
        "Image": "categories_images\\indoor.jpg"
    },
    {
        "ID": "cat-10",
        "Description": "downtown",
        "Image": "categories_images\\downtown.jpg"
    },
    {
        "ID": "cat-11",
        "Description": "shopping",
        "Image": "categories_images\\shopping.jpg"
    }
]
