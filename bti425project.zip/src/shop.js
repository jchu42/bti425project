export default {
    "name":"Places to go in Toronto",
    "description":"Sightseeing, but in your own backyard!"
}