"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/updatehistory";
exports.ids = ["pages/api/updatehistory"];
exports.modules = {

/***/ "bcrypt":
/*!*************************!*\
  !*** external "bcrypt" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ "jsonwebtoken":
/*!*******************************!*\
  !*** external "jsonwebtoken" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ "mongodb":
/*!**************************!*\
  !*** external "mongodb" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ "next/dist/compiled/next-server/pages-api.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages-api.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages-api.runtime.dev.js");

/***/ }),

/***/ "(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fupdatehistory&preferredRegion=&absolutePagePath=.%2Fsrc%5Cpages%5Capi%5Cupdatehistory.js&middlewareConfigBase64=e30%3D!":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fupdatehistory&preferredRegion=&absolutePagePath=.%2Fsrc%5Cpages%5Capi%5Cupdatehistory.js&middlewareConfigBase64=e30%3D! ***!
  \**************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   routeModule: () => (/* binding */ routeModule)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages-api/module.compiled */ \"(api)/./node_modules/next/dist/server/future/route-modules/pages-api/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(api)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"(api)/./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var _src_pages_api_updatehistory_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src\\pages\\api\\updatehistory.js */ \"(api)/./src/pages/api/updatehistory.js\");\n\n\n\n// Import the userland code.\n\n// Re-export the handler (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_src_pages_api_updatehistory_js__WEBPACK_IMPORTED_MODULE_3__, \"default\"));\n// Re-export config.\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_src_pages_api_updatehistory_js__WEBPACK_IMPORTED_MODULE_3__, \"config\");\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesAPIRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES_API,\n        page: \"/api/updatehistory\",\n        pathname: \"/api/updatehistory\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    userland: _src_pages_api_updatehistory_js__WEBPACK_IMPORTED_MODULE_3__\n});\n\n//# sourceMappingURL=pages-api.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTX0FQSSZwYWdlPSUyRmFwaSUyRnVwZGF0ZWhpc3RvcnkmcHJlZmVycmVkUmVnaW9uPSZhYnNvbHV0ZVBhZ2VQYXRoPS4lMkZzcmMlNUNwYWdlcyU1Q2FwaSU1Q3VwZGF0ZWhpc3RvcnkuanMmbWlkZGxld2FyZUNvbmZpZ0Jhc2U2ND1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQXNHO0FBQ3ZDO0FBQ0w7QUFDMUQ7QUFDZ0U7QUFDaEU7QUFDQSxpRUFBZSx3RUFBSyxDQUFDLDREQUFRLFlBQVksRUFBQztBQUMxQztBQUNPLGVBQWUsd0VBQUssQ0FBQyw0REFBUTtBQUNwQztBQUNPLHdCQUF3QixnSEFBbUI7QUFDbEQ7QUFDQSxjQUFjLHlFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsWUFBWTtBQUNaLENBQUM7O0FBRUQiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vPzQ4NWYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGFnZXNBUElSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1tb2R1bGVzL3BhZ2VzLWFwaS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1raW5kXCI7XG5pbXBvcnQgeyBob2lzdCB9IGZyb20gXCJuZXh0L2Rpc3QvYnVpbGQvdGVtcGxhdGVzL2hlbHBlcnNcIjtcbi8vIEltcG9ydCB0aGUgdXNlcmxhbmQgY29kZS5cbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCIuL3NyY1xcXFxwYWdlc1xcXFxhcGlcXFxcdXBkYXRlaGlzdG9yeS5qc1wiO1xuLy8gUmUtZXhwb3J0IHRoZSBoYW5kbGVyIChzaG91bGQgYmUgdGhlIGRlZmF1bHQgZXhwb3J0KS5cbmV4cG9ydCBkZWZhdWx0IGhvaXN0KHVzZXJsYW5kLCBcImRlZmF1bHRcIik7XG4vLyBSZS1leHBvcnQgY29uZmlnLlxuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IGhvaXN0KHVzZXJsYW5kLCBcImNvbmZpZ1wiKTtcbi8vIENyZWF0ZSBhbmQgZXhwb3J0IHRoZSByb3V0ZSBtb2R1bGUgdGhhdCB3aWxsIGJlIGNvbnN1bWVkLlxuZXhwb3J0IGNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IFBhZ2VzQVBJUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLlBBR0VTX0FQSSxcbiAgICAgICAgcGFnZTogXCIvYXBpL3VwZGF0ZWhpc3RvcnlcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS91cGRhdGVoaXN0b3J5XCIsXG4gICAgICAgIC8vIFRoZSBmb2xsb3dpbmcgYXJlbid0IHVzZWQgaW4gcHJvZHVjdGlvbi5cbiAgICAgICAgYnVuZGxlUGF0aDogXCJcIixcbiAgICAgICAgZmlsZW5hbWU6IFwiXCJcbiAgICB9LFxuICAgIHVzZXJsYW5kXG59KTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFnZXMtYXBpLmpzLm1hcCJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fupdatehistory&preferredRegion=&absolutePagePath=.%2Fsrc%5Cpages%5Capi%5Cupdatehistory.js&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "(api)/./src/pages/api/updatehistory.js":
/*!****************************************!*\
  !*** ./src/pages/api/updatehistory.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ updatehistory)\n/* harmony export */ });\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongodb */ \"mongodb\");\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bcrypt */ \"bcrypt\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jsonwebtoken */ \"jsonwebtoken\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__);\n// pages/api/login.js\n\n\n\nasync function updatehistory(req, res) {\n    if (req.method === \"POST\") {\n        const token = req.headers.authorization;\n        const history = req.headers.history;\n        var username = \"\";\n        try {\n            username = jsonwebtoken__WEBPACK_IMPORTED_MODULE_2___default().verify(token, process.env.JWT_SECRET).username;\n        } catch (error) {\n            res.status(401).json({\n                message: \"Invalid token\"\n            });\n            return;\n        }\n        try {\n            // Connect to MongoDB\n            const client = new mongodb__WEBPACK_IMPORTED_MODULE_0__.MongoClient(process.env.MONGODB_URI);\n            await client.connect();\n            // Check if the username and password match a user in the database\n            const db = client.db(\"BTIProject\");\n            const usersCollection = db.collection(\"users\");\n            const user = await usersCollection.findOne({\n                username\n            });\n            if (user) {\n                //const history = user.history;\n                await usersCollection.updateOne({\n                    username\n                }, {\n                    $set: {\n                        history: history\n                    }\n                });\n                res.status(200).json({\n                    message: \"synced history\"\n                });\n            } else {\n                console.log(\"Username: \", username);\n                console.log(\"User: \", user);\n                // If user does not exist, return an error response\n                res.status(401).json({\n                    message: \"Username does not exist\"\n                });\n            }\n            await client.close();\n        } catch (error) {\n            console.error(\"Error logging in:\", error);\n            res.status(500).json({\n                message: \"Internal server error\"\n            });\n        }\n    } else {\n        res.status(405).json({\n            message: \"Method not allowed\"\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMvcGFnZXMvYXBpL3VwZGF0ZWhpc3RvcnkuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLHFCQUFxQjtBQUVpQjtBQUNWO0FBQ0c7QUFFaEIsZUFBZUcsY0FBY0MsR0FBRyxFQUFFQyxHQUFHO0lBQ2xELElBQUlELElBQUlFLE1BQU0sS0FBSyxRQUFRO1FBQ3pCLE1BQU1DLFFBQVFILElBQUlJLE9BQU8sQ0FBQ0MsYUFBYTtRQUN2QyxNQUFNQyxVQUFVTixJQUFJSSxPQUFPLENBQUNFLE9BQU87UUFDbkMsSUFBSUMsV0FBVztRQUNmLElBQUk7WUFDQUEsV0FBV1QsMERBQVUsQ0FBQ0ssT0FBT00sUUFBUUMsR0FBRyxDQUFDQyxVQUFVLEVBQUVKLFFBQVE7UUFDakUsRUFDQSxPQUFPSyxPQUFNO1lBQ1hYLElBQUlZLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7Z0JBQUNDLFNBQVM7WUFBZTtZQUM5QztRQUNGO1FBQ0EsSUFBRztZQUVDLHFCQUFxQjtZQUNyQixNQUFNQyxTQUFTLElBQUlwQixnREFBV0EsQ0FBQ2EsUUFBUUMsR0FBRyxDQUFDTyxXQUFXO1lBQ3RELE1BQU1ELE9BQU9FLE9BQU87WUFFcEIsa0VBQWtFO1lBQ2xFLE1BQU1DLEtBQUtILE9BQU9HLEVBQUUsQ0FBQztZQUNyQixNQUFNQyxrQkFBa0JELEdBQUdFLFVBQVUsQ0FBQztZQUN0QyxNQUFNQyxPQUFPLE1BQU1GLGdCQUFnQkcsT0FBTyxDQUFDO2dCQUFFaEI7WUFBUTtZQUVyRCxJQUFJZSxNQUFNO2dCQUNOLCtCQUErQjtnQkFFL0IsTUFBTUYsZ0JBQWdCSSxTQUFTLENBQUM7b0JBQUVqQjtnQkFBUyxHQUFHO29CQUFDa0IsTUFBTTt3QkFBQ25CLFNBQVNBO29CQUFPO2dCQUFDO2dCQUV2RUwsSUFBSVksTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztvQkFBQ0MsU0FBUztnQkFBZ0I7WUFDbkQsT0FBTztnQkFDSFcsUUFBUUMsR0FBRyxDQUFFLGNBQWNwQjtnQkFDM0JtQixRQUFRQyxHQUFHLENBQUMsVUFBVUw7Z0JBQ3RCLG1EQUFtRDtnQkFDbkRyQixJQUFJWSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO29CQUFFQyxTQUFTO2dCQUEwQjtZQUM5RDtZQUNBLE1BQU1DLE9BQU9ZLEtBQUs7UUFDdEIsRUFBRSxPQUFPaEIsT0FBTztZQUNkYyxRQUFRZCxLQUFLLENBQUMscUJBQXFCQTtZQUNuQ1gsSUFBSVksTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztnQkFBRUMsU0FBUztZQUF3QjtRQUMxRDtJQUNGLE9BQU87UUFDTGQsSUFBSVksTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztZQUFFQyxTQUFTO1FBQXFCO0lBQ3ZEO0FBQ0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvcGFnZXMvYXBpL3VwZGF0ZWhpc3RvcnkuanM/YmMwZiJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBwYWdlcy9hcGkvbG9naW4uanNcclxuXHJcbmltcG9ydCB7IE1vbmdvQ2xpZW50IH0gZnJvbSAnbW9uZ29kYic7XHJcbmltcG9ydCBiY3J5cHQgZnJvbSAnYmNyeXB0JztcclxuaW1wb3J0IGp3dCBmcm9tICdqc29ud2VidG9rZW4nO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlaGlzdG9yeShyZXEsIHJlcykge1xyXG4gIGlmIChyZXEubWV0aG9kID09PSAnUE9TVCcpIHtcclxuICAgIGNvbnN0IHRva2VuID0gcmVxLmhlYWRlcnMuYXV0aG9yaXphdGlvbjtcclxuICAgIGNvbnN0IGhpc3RvcnkgPSByZXEuaGVhZGVycy5oaXN0b3J5XHJcbiAgICB2YXIgdXNlcm5hbWUgPSBcIlwiXHJcbiAgICB0cnkge1xyXG4gICAgICAgIHVzZXJuYW1lID0gand0LnZlcmlmeSh0b2tlbiwgcHJvY2Vzcy5lbnYuSldUX1NFQ1JFVCkudXNlcm5hbWU7XHJcbiAgICB9XHJcbiAgICBjYXRjaCAoZXJyb3Ipe1xyXG4gICAgICByZXMuc3RhdHVzKDQwMSkuanNvbih7bWVzc2FnZTogXCJJbnZhbGlkIHRva2VuXCJ9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgdHJ5e1xyXG5cclxuICAgICAgICAvLyBDb25uZWN0IHRvIE1vbmdvREJcclxuICAgICAgICBjb25zdCBjbGllbnQgPSBuZXcgTW9uZ29DbGllbnQocHJvY2Vzcy5lbnYuTU9OR09EQl9VUkkpO1xyXG4gICAgICAgIGF3YWl0IGNsaWVudC5jb25uZWN0KCk7XHJcblxyXG4gICAgICAgIC8vIENoZWNrIGlmIHRoZSB1c2VybmFtZSBhbmQgcGFzc3dvcmQgbWF0Y2ggYSB1c2VyIGluIHRoZSBkYXRhYmFzZVxyXG4gICAgICAgIGNvbnN0IGRiID0gY2xpZW50LmRiKCdCVElQcm9qZWN0Jyk7XHJcbiAgICAgICAgY29uc3QgdXNlcnNDb2xsZWN0aW9uID0gZGIuY29sbGVjdGlvbigndXNlcnMnKTtcclxuICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgdXNlcnNDb2xsZWN0aW9uLmZpbmRPbmUoeyB1c2VybmFtZX0pO1xyXG5cclxuICAgICAgICBpZiAodXNlcikge1xyXG4gICAgICAgICAgICAvL2NvbnN0IGhpc3RvcnkgPSB1c2VyLmhpc3Rvcnk7XHJcblxyXG4gICAgICAgICAgICBhd2FpdCB1c2Vyc0NvbGxlY3Rpb24udXBkYXRlT25lKHsgdXNlcm5hbWUgfSwgeyRzZXQ6IHtoaXN0b3J5OiBoaXN0b3J5fX0pO1xyXG5cclxuICAgICAgICAgICAgcmVzLnN0YXR1cygyMDApLmpzb24oe21lc3NhZ2U6IFwic3luY2VkIGhpc3RvcnlcIn0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChcIlVzZXJuYW1lOiBcIiwgdXNlcm5hbWUpXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiVXNlcjogXCIsIHVzZXIpXHJcbiAgICAgICAgICAgIC8vIElmIHVzZXIgZG9lcyBub3QgZXhpc3QsIHJldHVybiBhbiBlcnJvciByZXNwb25zZVxyXG4gICAgICAgICAgICByZXMuc3RhdHVzKDQwMSkuanNvbih7IG1lc3NhZ2U6ICdVc2VybmFtZSBkb2VzIG5vdCBleGlzdCcgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGF3YWl0IGNsaWVudC5jbG9zZSgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgbG9nZ2luZyBpbjonLCBlcnJvcik7XHJcbiAgICAgIHJlcy5zdGF0dXMoNTAwKS5qc29uKHsgbWVzc2FnZTogJ0ludGVybmFsIHNlcnZlciBlcnJvcicgfSk7XHJcbiAgICB9XHJcbiAgfSBlbHNlIHtcclxuICAgIHJlcy5zdGF0dXMoNDA1KS5qc29uKHsgbWVzc2FnZTogJ01ldGhvZCBub3QgYWxsb3dlZCcgfSk7XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6WyJNb25nb0NsaWVudCIsImJjcnlwdCIsImp3dCIsInVwZGF0ZWhpc3RvcnkiLCJyZXEiLCJyZXMiLCJtZXRob2QiLCJ0b2tlbiIsImhlYWRlcnMiLCJhdXRob3JpemF0aW9uIiwiaGlzdG9yeSIsInVzZXJuYW1lIiwidmVyaWZ5IiwicHJvY2VzcyIsImVudiIsIkpXVF9TRUNSRVQiLCJlcnJvciIsInN0YXR1cyIsImpzb24iLCJtZXNzYWdlIiwiY2xpZW50IiwiTU9OR09EQl9VUkkiLCJjb25uZWN0IiwiZGIiLCJ1c2Vyc0NvbGxlY3Rpb24iLCJjb2xsZWN0aW9uIiwidXNlciIsImZpbmRPbmUiLCJ1cGRhdGVPbmUiLCIkc2V0IiwiY29uc29sZSIsImxvZyIsImNsb3NlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./src/pages/api/updatehistory.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next"], () => (__webpack_exec__("(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fupdatehistory&preferredRegion=&absolutePagePath=.%2Fsrc%5Cpages%5Capi%5Cupdatehistory.js&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();